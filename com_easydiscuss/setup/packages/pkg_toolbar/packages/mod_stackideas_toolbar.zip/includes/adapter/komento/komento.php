<?php
/**
* @package      StackIdeas
* @copyright    Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license      GNU/GPL, see LICENSE.php
* StackIdeas Toolbar is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

class ToolbarAdapterKomento extends ToolbarAdapter
{
	public $component = 'com_komento';
	public $shortName = 'kt';
	public $jsName = 'Komento';

	public function __construct()
	{
		// Ensure that Komento is loaded in the page
		require_once(JPATH_ADMINISTRATOR . '/components/com_komento/includes/komento.php');
	}

	public function config()
	{
		return KT::config();
	}

	public function getUser($id = null)
	{
		$user = KT::user($id);

		return $user;
	}
}